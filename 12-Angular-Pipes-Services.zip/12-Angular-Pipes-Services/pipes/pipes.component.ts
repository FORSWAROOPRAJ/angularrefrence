import { Component, OnInit } from '@angular/core';

interface Employee{
  id : string;
  name : string;
  age : number;
  designation : string;
  joining : Date;
  salary : number;
}

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent implements OnInit {

  public employee:Employee = {
    id : 'aa101',
    name : 'John',
    age : 35,
    designation : 'Tech Lead',
    joining : new Date(),
    salary : 45000
  };

  constructor() { }

  ngOnInit(): void {
  }

}
