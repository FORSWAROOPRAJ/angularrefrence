export interface IStock {
  id : number,
  name : string,
  market : string,
  symbol : string,
  sector : string,
  industry : string,
  currency_code : string
}
